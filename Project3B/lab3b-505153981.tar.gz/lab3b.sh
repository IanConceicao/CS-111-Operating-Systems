#NAME: Ian Conceicao
#EMAIL: IanCon234@gmail.com
#ID: 505153981

python lab3b.py $@
